1. The source dataset is present under the source folder.
2. Before loading the file, have performed some transformations, and this processed file is present in the processed folder. 
3. Pandas will be reading the file from the processed folder. 
4. The questions posed by IMT are at the end of the notebook. The rest of the notebook is just basic EDA which I did to practice. 

